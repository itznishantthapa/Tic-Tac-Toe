let boxes = document.querySelectorAll(".boxes");
console.log(boxes);
var counting = 0;
let winnerScripts = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [6, 4, 2]
];

let player1colors = document.querySelectorAll(".player1-colors");
let player2colors = document.querySelectorAll(".player2-colors");

var isColor1Selected = false;
var isColor2Selected = false;

var selectedColor1 = "";
player1colors.forEach((color1) => {
    color1.addEventListener("click", () => {
        selectedColor1 = color1.style.backgroundColor;
        isColor1Selected = true;
        console.log(`Player1 selected color is ${selectedColor1}`);
        document.getElementById("span1").style.color=selectedColor1;
        document.getElementById("span1").innerText = `${selectedColor1}`;
       
    });
});

var selectedColor2 = "";
player2colors.forEach((color2) => {
    color2.addEventListener("click", () => {
        selectedColor2 = color2.style.backgroundColor;
        isColor2Selected = true;
        console.log(`Player2 selected color is ${selectedColor2}`);
        document.getElementById("span2").style.color=selectedColor2;
        document.getElementById("span2").innerText = `${selectedColor2}`;
    });
});

// to make a turn alternate
var turnForX = true;



boxes.forEach((box) => {
    box.addEventListener("click", () => {
        if (isColor1Selected && isColor2Selected) {
            console.log("box was clicked");
            if (turnForX) {

                box.style.backgroundColor = selectedColor1;
                console.log(`${selectedColor1} was applied.`);
                turnForX = false;
                counting = counting + 1;

                // indicator for next turn
                // document.getElementById("player-color-container2").style.borderColor="black";
                // document.getElementById("player-color-container1").style.borderColor="#e5e5e5";

            }
            else {

                box.style.backgroundColor = selectedColor2;
                turnForX = true;
                counting = counting + 1;

                // indicator for next turn
                // document.getElementById("player-color-container1").style.borderColor="black";
                // document.getElementById("player-color-container2").style.borderColor="#e5e5e5";
    
            }
            indicatorForNextTurn();
            box.disabled = true;
            rematch();
            checkForWinner();
        }
        else {
            alert("Please select the color");
        }

    });
});

document.getElementById("changeTurn").addEventListener("click",()=>{
    if(turnForX){
        document.getElementById("player-color-container2").style.borderColor=selectedColor2 || "black";
        document.getElementById("player-color-container1").style.borderColor="#e5e5e5";
        turnForX=false;
    }
    else{
        document.getElementById("player-color-container1").style.borderColor=selectedColor1 || "black";
        document.getElementById("player-color-container2").style.borderColor="#e5e5e5";
        turnForX=true;
    }
});


const indicatorForNextTurn=()=>{
    if(turnForX){
        document.getElementById("player-color-container1").style.borderColor="black";
        document.getElementById("player-color-container2").style.borderColor="#e5e5e5";
    }
    else{
        document.getElementById("player-color-container2").style.borderColor="black";
        document.getElementById("player-color-container1").style.borderColor="#e5e5e5";
    }
}

const checkForWinner = () => {
    for (let winPattern of winnerScripts) {

        console.log(winPattern[0], winPattern[1], winPattern[2]);

        const pattern1 = boxes[winPattern[0]].style.backgroundColor
        const pattern2 = boxes[winPattern[1]].style.backgroundColor
        const pattern3 = boxes[winPattern[2]].style.backgroundColor


        if (pattern1 != "" && pattern2 != "" && pattern3 != "") {
            if (pattern1 == selectedColor1 && pattern2 == selectedColor1 && pattern3 == selectedColor1 || pattern1 == selectedColor2 && pattern2 == selectedColor2 && pattern3 == selectedColor2) {
                console.log("winner is " + pattern1);
                document.querySelector(".para2").innerText = `Player ${pattern1}, You won the game`;
                signatureFunction(pattern1,true);
                 document.body.style.backgroundColor=pattern1;
                PopUp();
                newGame();
                closeDialog();
                return;

            }
            if (counting == 9){
                document.querySelector(".para2").innerText = `Player ${pattern1}, You defended well`;
                document.body.style.backgroundColor=pattern1;
                signatureFunction(pattern1,false);
                PopUp();
                newGame();
                closeDialog();
            }


        }

    }

}

let signatureCollection =document.querySelectorAll(".signature");

const signatureFunction=(pattern1,TF)=>signatureCollection.forEach((signature)=>{

   if(TF){
        signature.innerText=`${pattern1} wins`;
        // signature.classList.toggle("animate");
    }
    else{
        signature.innerText=`${pattern1} defended`;
        // signature.classList.toggle("animate");
    }

});



const PopUp = () => {
    document.getElementById("overlay").style.display = "flex";
}

const newGame = () => {
    document.getElementById("newGame-btn").addEventListener("click", () => {
        // iterating over a NodeList to access each box
        boxes.forEach((box) => {
            box.style.backgroundColor = "white";
            box.disabled = false;
            box.style.pointerEvents = "auto";
        });
          // removing text from the signature boxes
           signatureCollection.forEach((signature)=>{
            signature.innerText="";
        });
        document.body.style.backgroundColor="#e5e5e5";
        document.getElementById("overlay").style.display = "none";
        counting = 0;



    });
}

const closeDialog = () => {

    document.getElementById("C-btn").addEventListener("click", () => {
        boxes.forEach((box) => {
            box.style.pointerEvents = "none";
        });
        document.getElementById("overlay").style.display = "none";
    });

}

const rematch = () => {
    document.getElementById("re-match").addEventListener("click", () => {
        // iterating over a NodeList to access each box
        boxes.forEach((box) => {
            box.style.backgroundColor = "white";
            box.disabled = false;
            box.style.pointerEvents = "auto";
            // box.style.visibility = "visible";
        });

        document.body.style.backgroundColor="#e5e5e5";
        // removing text from the signature boxes
        signatureCollection.forEach((signature)=>{
            signature.innerText="";
        });
        counting = 0;
        // document.querySelector(".para2").innerText="";

    });
}
